package com.WizzyTR.quicknotes;

import android.animation.*;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private HashMap<String, Object> notemap = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> noteslistmap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> LanguageData = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ImageView CuickNotesMainLogo;
	private LinearLayout linear4;
	private ImageView settingsbutton;
	private ListView listview1;
	private AdView adview1;
	private ImageView imageview2;
	
	private Intent intent = new Intent();
	private SharedPreferences sp;
	private AlertDialog.Builder dialog;
	private ObjectAnimator objectanimator = new ObjectAnimator();
	private TimerTask timer;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		CuickNotesMainLogo = findViewById(R.id.CuickNotesMainLogo);
		linear4 = findViewById(R.id.linear4);
		settingsbutton = findViewById(R.id.settingsbutton);
		listview1 = findViewById(R.id.listview1);
		adview1 = findViewById(R.id.adview1);
		imageview2 = findViewById(R.id.imageview2);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		dialog = new AlertDialog.Builder(this);
		
		CuickNotesMainLogo.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				MainActivityCT = new CustomToastByArabWare(MainActivity.this);
				MainActivityCT.setLayout(R.layout.heart);
				MainActivityCT.show();
			}
		});
		
		settingsbutton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), SettingsActivity.class);
				startActivity(intent);
			}
		});
		
		adview1.setAdListener(new AdListener() {
			@Override
			public void onAdLoaded() {
				
			}
			
			@Override
			public void onAdFailedToLoad(LoadAdError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
			
			@Override
			public void onAdOpened() {
				
			}
			
			@Override
			public void onAdClicked() {
				
			}
			
			@Override
			public void onAdClosed() {
				
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				objectanimator.setTarget(imageview2);
				objectanimator.setDuration((int)(200));
				objectanimator.setPropertyName("translationY");
				objectanimator.setFloatValues((float)(0), (float)(-180));
				objectanimator.start();
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								objectanimator.setPropertyName("translationY");
								objectanimator.setFloatValues((float)(-180), (float)(0));
								objectanimator.setDuration((int)(100));
								objectanimator.start();
							}
						});
					}
				};
				_timer.schedule(timer, (int)(200));
				intent.putExtra("isEdit", "false");
				intent.setClass(getApplicationContext(), NotescreenActivity.class);
				startActivity(intent);
			}
		});
	}
	
	private void initializeLogic() {
		if (sp.contains("Data")) {
			noteslistmap = new Gson().fromJson(sp.getString("Data", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		}
		if (!sp.contains("CurrentLang")) {
			if (Locale.getDefault().getDisplayLanguage().equals("Türkçe")) {
				sp.edit().putString("CurrentLang", "Türkçe").commit();
			}
			if (Locale.getDefault().getDisplayLanguage().equals("English")) {
				sp.edit().putString("CurrentLang", "English").commit();
			}
			if (!(Locale.getDefault().getDisplayLanguage().equals("English") || Locale.getDefault().getDisplayLanguage().equals("Türkçe"))) {
				sp.edit().putString("CurrentLang", "English").commit();
			}
		}
		if (getIntent().hasExtra("isEdit")) {
			if (getIntent().getStringExtra("isEdit").equals("edited")) {
				if (getIntent().hasExtra("notemain")) {
					notemap = new HashMap<>();
					notemap = new Gson().fromJson(getIntent().getStringExtra("notemain"), new TypeToken<HashMap<String, Object>>(){}.getType());
					noteslistmap.remove((int)(Double.parseDouble(getIntent().getStringExtra("Position"))));
					noteslistmap.add((int)0, notemap);
					sp.edit().putString("Data", new Gson().toJson(noteslistmap)).commit();
				}
			} else {
				if (getIntent().hasExtra("notemain")) {
					notemap = new HashMap<>();
					notemap = new Gson().fromJson(getIntent().getStringExtra("notemain"), new TypeToken<HashMap<String, Object>>(){}.getType());
					noteslistmap.add((int)0, notemap);
					sp.edit().putString("Data", new Gson().toJson(noteslistmap)).commit();
				}
			}
		} else {
			if (getIntent().hasExtra("notemain")) {
				notemap = new HashMap<>();
				notemap = new Gson().fromJson(getIntent().getStringExtra("notemain"), new TypeToken<HashMap<String, Object>>(){}.getType());
				noteslistmap.add((int)0, notemap);
				sp.edit().putString("Data", new Gson().toJson(noteslistmap)).commit();
			}
		}
		listview1.setAdapter(new Listview1Adapter(noteslistmap));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
		listview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)10, 0xFF616161, 0xFF424242));
		imageview2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / 24, (int)10, 0xFFFFFFFF, 0xFF212121));
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						{
							AdRequest adRequest = new AdRequest.Builder().build();
							adview1.loadAd(adRequest);
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(timer, (int)(1), (int)(59000));
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (sp.contains("Data")) {
			noteslistmap = new Gson().fromJson(sp.getString("Data", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		}
		listview1.setAdapter(new Listview1Adapter(noteslistmap));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (adview1 != null) {
			adview1.destroy();
		}
	}
	
	@Override
	public void onPause() {
		super.onPause();
		if (adview1 != null) {
			adview1.pause();
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		if (adview1 != null) {
			adview1.resume();
		}
	}
	public void _customtoast() {
	}
	
	public static class CustomToastByArabWare {
		
		private Toast toast;
		private View view;
		private Context context;
		private boolean isActivity;
		private Fragment fragmentContext;
		
		public CustomToastByArabWare(Activity activity) {
			
			
			context = activity;
			
			toast = Toast.makeText(context,"",2726);
			
			isActivity = true;
			
		}
		
		public CustomToastByArabWare(Fragment fragment) {
			
			fragmentContext = fragment;
			
			context = fragment.getActivity();
			
			toast = Toast.makeText(context,"",2726);
			
			isActivity = false;
			
		}
		
		public void setLayout(int layout) {
			
			if(isActivity) {
				
				view = (View) ((Activity)context).getLayoutInflater().inflate(layout, null);
				
			} else {
				
				view = (View) fragmentContext.getActivity().getLayoutInflater().inflate(layout, null);
				
			}
			
			toast.setView(view);
			
		}
		
		public void show() {
			
			toast.show();
			
		}
		
		public View getView(int viewId) {
			
			return view.findViewById(viewId);
			
		}
		
	}
	
	{
	}
	private CustomToastByArabWare MainActivityCT;
	{
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.custom_note_view, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			textview1.setText(noteslistmap.get((int)_position).get("Time").toString());
			textview2.setText(noteslistmap.get((int)_position).get("Note").toString());
			textview3.setText(noteslistmap.get((int)_position).get("Date").toString());
			textview3.setTextSize((int)8);
			if (textview2.getText().toString().length() > 300) {
				textview2.setTextSize((int)12);
				linear3.setLayoutParams(new LinearLayout.LayoutParams((int) (android.widget.LinearLayout.LayoutParams.MATCH_PARENT),(int) (208)));
				linear1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						linear3.setLayoutParams(new LinearLayout.LayoutParams((int) (android.widget.LinearLayout.LayoutParams.MATCH_PARENT),(int) (android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)));
						if (linear3.getHeight() > 208) {
							intent.putExtra("Note", noteslistmap.get((int)_position).get("Note").toString());
							intent.putExtra("isEdit", "true");
							intent.putExtra("Position", String.valueOf((long)(_position)));
							intent.setClass(getApplicationContext(), NotescreenActivity.class);
							startActivity(intent);
						}
					}
				});
			} else {
				textview2.setTextSize((int)14);
				linear3.setLayoutParams(new LinearLayout.LayoutParams((int) (android.widget.LinearLayout.LayoutParams.MATCH_PARENT),(int) (android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)));
				linear1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						intent.putExtra("Note", noteslistmap.get((int)_position).get("Note").toString());
						intent.putExtra("isEdit", "true");
						intent.putExtra("Position", String.valueOf((long)(_position)));
						intent.setClass(getApplicationContext(), NotescreenActivity.class);
						startActivity(intent);
					}
				});
			}
			linear1.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View _view) {
					if (sp.getString("CurrentLang", "").equals("Türkçe")) {
						final AlertDialog dialog = new AlertDialog.Builder(MainActivity.this).create();
						View inflate = getLayoutInflater().inflate(R.layout.delete_note,null); 
						dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
						dialog.setView(inflate);
						LinearLayout bg = (LinearLayout) inflate.findViewById(R.id.bg);
						TextView cancel = (TextView) inflate.findViewById(R.id.cancel);
						cancel.setText("İptal");
						TextView delete = (TextView) inflate.findViewById(R.id.delete);
						delete.setText("Sil");
						TextView share = (TextView) inflate.findViewById(R.id.share);
						share.setText("Paylaş");
						TextView title = (TextView) inflate.findViewById(R.id.title);
						title.setText("Notu Sil veya Paylaş");
						TextView description = (TextView) inflate.findViewById(R.id.description);
						description.setText("Bu notu silmek veya paylaşmak ister misiniz?\n(Mesajı silmek kalıcıdır!)");
						bg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / 80, (int)5, 0xFF424242, 0xFF616161));
						cancel.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
								dialog.dismiss();
							}
						});
						delete.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
								noteslistmap.remove((int)(_position));
								listview1.setAdapter(new Listview1Adapter(noteslistmap));
								((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
								sp.edit().putString("Data", new Gson().toJson(noteslistmap)).commit();
								dialog.dismiss();
							}
						});
						share.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
								Intent i = new Intent(android.content.Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(android.content.Intent.EXTRA_TEXT, noteslistmap.get((int)_position).get("Note").toString()); startActivity(Intent.createChooser(i,"Share Note"));
								dialog.dismiss();
							}
						});
						dialog.setCancelable(true);
						dialog.show();
					}
					if (sp.getString("CurrentLang", "").equals("English")) {
						final AlertDialog dialog = new AlertDialog.Builder(MainActivity.this).create();
						View inflate = getLayoutInflater().inflate(R.layout.delete_note,null); 
						dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
						dialog.setView(inflate);
						LinearLayout bg = (LinearLayout) inflate.findViewById(R.id.bg);
						TextView cancel = (TextView) inflate.findViewById(R.id.cancel);
						cancel.setText("Cancel");
						TextView delete = (TextView) inflate.findViewById(R.id.delete);
						delete.setText("Delete");
						TextView share = (TextView) inflate.findViewById(R.id.share);
						share.setText("Share");
						TextView title = (TextView) inflate.findViewById(R.id.title);
						title.setText("Delete or Share Note");
						TextView description = (TextView) inflate.findViewById(R.id.description);
						description.setText("Do you want to delete or share this note?\n(Deleting message is permanent!)");
						bg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / 80, (int)5, 0xFF424242, 0xFF616161));
						cancel.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
								dialog.dismiss();
							}
						});
						delete.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
								noteslistmap.remove((int)(_position));
								listview1.setAdapter(new Listview1Adapter(noteslistmap));
								((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
								sp.edit().putString("Data", new Gson().toJson(noteslistmap)).commit();
								dialog.dismiss();
							}
						});
						share.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
								Intent i = new Intent(android.content.Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(android.content.Intent.EXTRA_TEXT, noteslistmap.get((int)_position).get("Note").toString()); startActivity(Intent.createChooser(i,"Share Note"));
								dialog.dismiss();
							}
						});
						dialog.setCancelable(true);
						dialog.show();
					}
					return true;
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}