package com.WizzyTR.quicknotes;

import android.animation.*;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.gms.ads.MobileAds;
import com.google.gson.Gson;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class NotescreenActivity extends Activity {
	
	private HashMap<String, Object> notemap = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private LinearLayout linear1;
	private EditText edittext1;
	private ImageView imageview1;
	private TextView newnote;
	private ImageView imageview2;
	
	private Intent intent = new Intent();
	private Calendar calendar = Calendar.getInstance();
	private ObjectAnimator ObjectAnimator = new ObjectAnimator();
	private SharedPreferences sp;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.notescreen);
		initialize(_savedInstanceState);
		
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		edittext1 = findViewById(R.id.edittext1);
		imageview1 = findViewById(R.id.imageview1);
		newnote = findViewById(R.id.newnote);
		imageview2 = findViewById(R.id.imageview2);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (edittext1.getText().toString().equals("")) {
					edittext1.setTextSize((int)20);
					edittext1.setTypeface(Typeface.DEFAULT, 2);
				} else {
					edittext1.setTextSize((int)16);
					edittext1.setTypeface(Typeface.DEFAULT, 0);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().equals(getIntent().getStringExtra("Note"))) {
					if (sp.getString("CurrentLang", "").equals("Türkçe")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Düzenlenmedi");
					}
					if (sp.getString("CurrentLang", "").equals("English")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Not edited");
					}
					intent.setClass(getApplicationContext(), MainActivity.class);
					startActivity(intent);
					finish();
				} else {
					if (edittext1.getText().toString().equals("")) {
						if (sp.getString("CurrentLang", "").equals("Türkçe")) {
							SketchwareUtil.showMessage(getApplicationContext(), "Not boş kaydedilemez!");
						}
						if (sp.getString("CurrentLang", "").equals("English")) {
							SketchwareUtil.showMessage(getApplicationContext(), "Note cannot be saved as empty!");
						}
					} else {
						if (getIntent().getStringExtra("isEdit").equals("true") && getIntent().hasExtra("Position")) {
							intent.putExtra("Position", getIntent().getStringExtra("Position"));
							intent.putExtra("isEdit", "edited");
							notemap = new HashMap<>();
							notemap.put("Note", edittext1.getText().toString());
							calendar = Calendar.getInstance();
							notemap.put("Time", new SimpleDateFormat("HH:mm").format(calendar.getTime()));
							notemap.put("Date", new SimpleDateFormat("dd.MM.y").format(calendar.getTime()));
							intent.putExtra("notemain", new Gson().toJson(notemap));
							intent.setClass(getApplicationContext(), MainActivity.class);
							notemap.clear();
							startActivity(intent);
							finish();
						} else {
							notemap = new HashMap<>();
							notemap.put("Note", edittext1.getText().toString());
							calendar = Calendar.getInstance();
							notemap.put("Time", new SimpleDateFormat("HH:mm").format(calendar.getTime()));
							notemap.put("Date", new SimpleDateFormat("dd.MM.y").format(calendar.getTime()));
							intent.putExtra("notemain", new Gson().toJson(notemap));
							intent.setClass(getApplicationContext(), MainActivity.class);
							notemap.clear();
							startActivity(intent);
							finish();
						}
					}
				}
			}
		});
	}
	
	private void initializeLogic() {
		if (sp.getString("CurrentLang", "").equals("Türkçe")) {
			if (getIntent().getStringExtra("isEdit").equals("true")) {
				newnote.setText("Hızlı Notu Düzenle");
				edittext1.setText(getIntent().getStringExtra("Note"));
			} else {
				newnote.setText("Yeni Hızlı Not");
				edittext1.setHint("Not yazınız...");
				edittext1.setText("");
				edittext1.requestFocus();
			}
		}
		if (sp.getString("CurrentLang", "").equals("English")) {
			if (getIntent().getStringExtra("isEdit").equals("true")) {
				newnote.setText("Edit Quick Note");
				edittext1.setText(getIntent().getStringExtra("Note"));
			} else {
				newnote.setText("New Quick Note");
				edittext1.setHint("Enter note...");
				edittext1.setText("");
				edittext1.requestFocus();
			}
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		
	}
	
	@Override
	public void onBackPressed() {
		if (!edittext1.getText().toString().equals("")) {
			imageview2.performClick();
		} else {
			intent.setClass(getApplicationContext(), MainActivity.class);
			startActivity(intent);
			finish();
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}