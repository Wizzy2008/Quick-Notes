package com.WizzyTR.quicknotes;

import android.Manifest;
import android.animation.*;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import com.google.android.gms.ads.MobileAds;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class SettingsActivity extends Activity {
	
	public final int REQ_CD_QUİCKNOTES_FİLEPİCK = 101;
	
	private Timer _timer = new Timer();
	
	private String currentLanguage = "";
	private double spinner_language = 0;
	private boolean wait = false;
	private double Export_Number = 0;
	
	private ArrayList<String> languageNames = new ArrayList<>();
	
	private LinearLayout toolbar;
	private LinearLayout linear3;
	private ImageView back;
	private TextView textview1;
	private ImageView reset_notes;
	private LinearLayout linear1;
	private LinearLayout linear4;
	private LinearLayout linear2;
	private TextView textview2;
	private Spinner spinner1;
	private TextView textview4;
	private LinearLayout linear5;
	private Button button3;
	private Button button2;
	private TextView textview3;
	private Button button1;
	
	private Intent intent = new Intent();
	private SharedPreferences sp;
	private AlertDialog.Builder dialog;
	private SharedPreferences splanguage;
	private Intent quicknotes_filepick = new Intent(Intent.ACTION_GET_CONTENT);
	private Calendar calendar = Calendar.getInstance();
	private TimerTask timer;
	private ObjectAnimator ObjectAnimator = new ObjectAnimator();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.settings);
		initialize(_savedInstanceState);
		
		MobileAds.initialize(this);
		
		
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			||checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			} else {
				initializeLogic();
			}
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		toolbar = findViewById(R.id.toolbar);
		linear3 = findViewById(R.id.linear3);
		back = findViewById(R.id.back);
		textview1 = findViewById(R.id.textview1);
		reset_notes = findViewById(R.id.reset_notes);
		linear1 = findViewById(R.id.linear1);
		linear4 = findViewById(R.id.linear4);
		linear2 = findViewById(R.id.linear2);
		textview2 = findViewById(R.id.textview2);
		spinner1 = findViewById(R.id.spinner1);
		textview4 = findViewById(R.id.textview4);
		linear5 = findViewById(R.id.linear5);
		button3 = findViewById(R.id.button3);
		button2 = findViewById(R.id.button2);
		textview3 = findViewById(R.id.textview3);
		button1 = findViewById(R.id.button1);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		dialog = new AlertDialog.Builder(this);
		splanguage = getSharedPreferences("splanguage", Activity.MODE_PRIVATE);
		quicknotes_filepick.setType("text/*");
		quicknotes_filepick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		
		back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		reset_notes.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (sp.getString("CurrentLang", "").equals("Türkçe")) {
					final AlertDialog dialog = new AlertDialog.Builder(SettingsActivity.this).create();
					View inflate = getLayoutInflater().inflate(R.layout.delete_note,null); 
					dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
					dialog.setView(inflate);
					LinearLayout bg = (LinearLayout) inflate.findViewById(R.id.bg);
					TextView title = (TextView) inflate.findViewById(R.id.title);
					title.setText("Tüm Notları Sil");
					TextView description = (TextView) inflate.findViewById(R.id.description);
					description.setText("Tüm notları silmek istiyor musunuz?\n(Bu işlem kalıcıdır ve geri alınamaz. Dikkatli olun!)\nEğer onaylıyorsanız sil butonuna basılı tutun!");
					TextView cancel = (TextView) inflate.findViewById(R.id.cancel);
					cancel.setText("İptal");
					TextView delete = (TextView) inflate.findViewById(R.id.delete);
					delete.setText("Delete");
					TextView share = (TextView) inflate.findViewById(R.id.share);
					share.setText("Sil");
					delete.setVisibility(View.INVISIBLE);
					bg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / 80, (int)5, 0xFF424242, 0xFF616161));
					share.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / 80, 0xFFD32F2F));
					cancel.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
							dialog.dismiss();
						}
					});
					share.setOnLongClickListener(new View.OnLongClickListener() {
						@Override
						public boolean onLongClick(View _view) {
							sp.edit().remove("Data").commit();
							SketchwareUtil.showMessage(getApplicationContext(), "Tüm notlar silindi, lütfen Quick Notes uygulamasını tekrar açın!");
							dialog.dismiss();
							finishAffinity();
							return true;
						}
					});
					share.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
							SketchwareUtil.showMessage(getApplicationContext(), "Basılı Tutun");
						}
					});
					dialog.setCancelable(true);
					dialog.show();
				}
				if (sp.getString("CurrentLang", "").equals("English")) {
					final AlertDialog dialog = new AlertDialog.Builder(SettingsActivity.this).create();
					View inflate = getLayoutInflater().inflate(R.layout.delete_note,null); 
					dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
					dialog.setView(inflate);
					LinearLayout bg = (LinearLayout) inflate.findViewById(R.id.bg);
					TextView title = (TextView) inflate.findViewById(R.id.title);
					title.setText("Delete All Notes");
					TextView description = (TextView) inflate.findViewById(R.id.description);
					description.setText("Do you want to delete all notes?\n(This operation is permanent and can't be undone. Be careful!)\nIf you want long click delete button!");
					TextView cancel = (TextView) inflate.findViewById(R.id.cancel);
					cancel.setText("Cancel");
					TextView delete = (TextView) inflate.findViewById(R.id.delete);
					delete.setText("Delete");
					TextView share = (TextView) inflate.findViewById(R.id.share);
					share.setText("Delete");
					delete.setVisibility(View.INVISIBLE);
					bg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / 80, (int)5, 0xFF424242, 0xFF616161));
					share.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / 80, 0xFFD32F2F));
					cancel.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
							dialog.dismiss();
						}
					});
					share.setOnLongClickListener(new View.OnLongClickListener() {
						@Override
						public boolean onLongClick(View _view) {
							sp.edit().remove("Data").commit();
							SketchwareUtil.showMessage(getApplicationContext(), "All notes deleted, please reopen quick notes app!");
							dialog.dismiss();
							finishAffinity();
							return true;
						}
					});
					share.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
							SketchwareUtil.showMessage(getApplicationContext(), "Long Click");
						}
					});
					dialog.setCancelable(true);
					dialog.show();
				}
				ObjectAnimator.setTarget(reset_notes);
				ObjectAnimator.setPropertyName("rotation");
				ObjectAnimator.setFloatValues((float)(0), (float)(-360));
				ObjectAnimator.setDuration((int)(1000));
				ObjectAnimator.setRepeatMode(ValueAnimator.REVERSE);
				ObjectAnimator.setInterpolator(new BounceInterpolator());
				ObjectAnimator.start();
			}
		});
		
		spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				textview1.setText(languageNames.get((int)(_position)));
				if (languageNames.get((int)(_position)).equals("Türkçe")) {
					sp.edit().putString("CurrentLang", "Türkçe").commit();
				}
				if (languageNames.get((int)(_position)).equals("English")) {
					sp.edit().putString("CurrentLang", "English").commit();
				}
				if (sp.getString("CurrentLang", "").equals("Türkçe")) {
					textview1.setText("Ayarlar");
					textview2.setText("Dil Seçimi");
					textview3.setText("Geliştirici Telegram kanalına katılın!");
					textview4.setText("Notları Yedekle/Geri Yükle");
					button3.setText("Yedekle");
					button2.setText("Geri Yükle");
					button1.setText("Katıl");
				}
				if (sp.getString("CurrentLang", "").equals("English")) {
					textview1.setText("Settings");
					textview2.setText("Select Language");
					textview3.setText("Join to developer Telegram channel!");
					textview4.setText("Export/Import Notes");
					button3.setText("Export");
					button2.setText("Import");
					button1.setText("Join");
				}
			}
			
			@Override
			public void onNothingSelected(AdapterView<?> _param1) {
				
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (sp.contains("Data")) {
					if (!sp.contains("Export")) {
						sp.edit().putString("Export", String.valueOf((long)(Export_Number))).commit();
					}
					Export_Number = Double.parseDouble(sp.getString("Export", ""));
					if (FileUtil.isExistFile(FileUtil.getPublicDir(Environment.DIRECTORY_DOWNLOADS).concat("/QuickNotes"))) {
						FileUtil.writeFile(FileUtil.getPublicDir(Environment.DIRECTORY_DOWNLOADS).concat("/QuickNotes/Backup".concat(String.valueOf((long)(Export_Number))).concat(".txt")), sp.getString("Data", ""));
						Export_Number++;
						SketchwareUtil.showMessage(getApplicationContext(), "Download".concat("/QuickNotes/Backup".concat(String.valueOf((long)(Export_Number - 1))).concat(".txt")));
					} else {
						FileUtil.makeDir(FileUtil.getPublicDir(Environment.DIRECTORY_DOWNLOADS).concat("/QuickNotes"));
						FileUtil.writeFile(FileUtil.getPublicDir(Environment.DIRECTORY_DOWNLOADS).concat("/QuickNotes/Backup".concat(String.valueOf((long)(Export_Number))).concat(".txt")), sp.getString("Data", ""));
						Export_Number++;
						SketchwareUtil.showMessage(getApplicationContext(), "Download".concat("/QuickNotes/Backup".concat(String.valueOf((long)(Export_Number - 1))).concat(".txt")));
					}
					sp.edit().putString("Export", String.valueOf((long)(Export_Number))).commit();
				} else {
					if (sp.getString("CurrentLang", "").equals("Türkçe")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Yedeklenecek herhangi bir not bulunmuyor!");
					}
					if (sp.getString("CurrentLang", "").equals("English")) {
						SketchwareUtil.showMessage(getApplicationContext(), "There is no any notes to export!");
					}
				}
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(quicknotes_filepick, REQ_CD_QUİCKNOTES_FİLEPİCK);
				if (sp.getString("CurrentLang", "").equals("Türkçe")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Geri yüklenen notlar halihazırdaki notların yerine geçer!");
				}
				if (sp.getString("CurrentLang", "").equals("English")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Imported notes will replace current notes!");
				}
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setAction(Intent.ACTION_VIEW);
				intent.setData(Uri.parse("https://t.me/WizzyTRsApps"));
				startActivity(intent);
			}
		});
	}
	
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_QUİCKNOTES_FİLEPİCK:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				sp.edit().putString("Data", FileUtil.readFile(_filePath.get((int)(0)))).commit();
				if (sp.getString("CurrentLang", "").equals("Türkçe")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Yedek geri yüklendi👍");
				}
				if (sp.getString("CurrentLang", "").equals("English")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Backup imported👍");
				}
				finish();
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (!wait) {
			languageNames.add("English");
			languageNames.add("Türkçe");
			spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, languageNames));
			((ArrayAdapter)spinner1.getAdapter()).notifyDataSetChanged();
			wait = true;
		}
		if (sp.getString("CurrentLang", "").equals("Türkçe")) {
			spinner1.setSelection((int)(1));
			textview1.setText("Ayarlar");
			textview2.setText("Dil Seçimi");
			textview3.setText("Geliştiricinin Telegram kanalına katılın!");
			textview4.setText("Notları Yedekle/Geri Yükle");
			button3.setText("Yedekle");
			button2.setText("Geri Yükle");
			button1.setText("Katıl");
		}
		if (sp.getString("CurrentLang", "").equals("English")) {
			spinner1.setSelection((int)(0));
			textview1.setText("Settings");
			textview2.setText("Select Language");
			textview3.setText("Join to developer Telegram channel!");
			textview4.setText("Export/Import Notes");
			button3.setText("Export");
			button2.setText("Import");
			button1.setText("Join");
		}
		spinner1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)4, 0xFF424242, 0xFFFFFFFF));
		button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)4, 0xFF424242, 0xFFFFFFFF));
		linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)4, 0xFF424242, 0xFFFFFFFF));
	}
	
	@Override
	public void onBackPressed() {
		finish();
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}